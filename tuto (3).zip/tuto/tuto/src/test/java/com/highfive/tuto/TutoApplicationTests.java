package com.highfive.tuto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
