package com.highfive.tuto.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

// import org.springframework.boot.context.properties.configurationProperties;


@ConfigurationProperties(prefix="application",ignoreUnknownFields=false)
@Getter
@Setter
public class ApplicationProperties{
    private String hello;
}